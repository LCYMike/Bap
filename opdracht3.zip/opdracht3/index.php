<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Opdracht 3</title>
</head>
<body>
<?php

    $firstName = 'Mike';
    $lastName = 'Raadsheer';

    $age = 17;

    $gendreMale = true;

        if ($age == 17)
        {
            echo "hier heb ik wat voordelen en nadelen aan 17 zijn voor je " . $firstName . "." . "<br>";
            echo "Voordeel :  je mag afrijden voor je auto rijbewijs!" . "<br>";
            echo "Nadeel :  je mag pas over een jaar afrijden voor je motor rijbewijs." . "<br>";
            echo "Nadeel :  je mag pas over een jaar drinken." . "<br>";
        }
        else if ($age >= 18)
        {
            echo "Yes je bent " . $age . " dus nu ben je lekker verantwoordenlijk voor jezelf" . $firstName . "<br>";
            echo "Dus nu moet je jezelf verzekeren mischien een baan zoekken maar hé" . "<br>";
            echo "je mag te minste drinken alleen auto rijden en je mag voor je motor rijbewijs gaan!!" . "<br>";
        }
        else if ($age == 16)
        {
            echo "Je bent 16 " . $firstName . " nu mag je voor je scooter rijbewijs gaan maar wacht even." . "<br>";
            echo "Mischien wil je wel een jaar wachten en voor je auto rijbewijs gaan dan mag je ook gelijk op de scooter!" . "<br>";
            echo "of je gaat over 2 jaar voor je motor rijbewijs maar dat kan alleen op 18 als je al je auto rijbewijs heb." . "<br>";
        }
        else if ($age <= 15)
        {
            echo "Arme jij je mag zowat niks." . "<br>";
            echo "Maar vrees niet " . $firstName . " want over een jaar begint je leven pas echt!" . "<br>";
        }


        echo "<br><br><br>";

?>

    <form>
        <input type="text" name="FirstName" value="First name">
        <input type="text" name="LastName" value="Last name">

        <br><br>
        <?php
            $months = array("Dummy","Januari","Februari","March",
                "April","Mei","June",
                "Juli","August","September",
                "Oktober","November","December");

            ?>
            <select name="day">
            <?php

            for ($d=1;$d<=31;$d++)
            {
                echo "<option name='$d'>$d </option>";
            }
            ?>
        </select>


        <select name="month">
            <?php
            for ($i=1;$i<=12;$i++)
            {
                echo "<option name='$i'>$months[$i]</option>";
            }


            ?>
        </select>

        <select name="year">
                <?php
                for ($j=2010;$j>=1945;$j--)
                {
                    echo "<option name='$j'>$j </option>";
                }
                ?>
        </select>
    </form>
<br><br>
 <p>just messing around with random thing found on youtube and forums...</p>
<br><br>


<table border="3" cellpadding="3">
<?php

    for ($x=1;$x<=100;$x++)
    {
        echo "<tr>";

        for ($y=1;$y<=10;$y++)
        {
            echo "<td align='middle'>" . $x*$y . "</td>";
        }

        echo "</tr>";
    }

?>
</table>
</body>
</html>