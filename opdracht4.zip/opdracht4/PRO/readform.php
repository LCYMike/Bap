<?php

$firstName = $_POST['firstName'];
$lastName = "boi";
$age = $_POST['age'];

$gendre = "other";

$country = $_POST['country'];

$rand = rand (0, 1);

switch ($firstName)
{
  case 'Donald':
      if ($rand == 0)
      {
      $lastName = 'Trump';
      $gendre = 'male';
      break;
      }
      else if ($rand == 1)
      {
      $lastName = 'Duck';
      $gendre = 'male';
      break;
      }
  case 'Kim':
      if ($rand == 0)
      {
      $lastName = 'Jong-Un';
      $gendre = 'male';
      break;
      }
      else if ($rand == 1)
      {
      $lastName = 'Kardashian';
      $gendre = 'female';
      break;
      }
  case 'Jack':
      if ($rand == 0)
      {
      $lastName = 'Ass';
      $gendre = 'male';
      break;
      }
      else if ($rand == 1)
      {
        $lastName = 'Septic Eye';
        $gendre = 'male';
        break;
      }
  case 'Henk':
      $lastName = '( ͡° ͜ʖ ͡°)';
      $gendre = 'male';
      break;
  case 'Adolf':
      $lastName = 'Hondler';
      $gendre = 'male';
      break;
  default:
  echo "I'm going yo assume your gendre just don't get triggered <br><br>";
  $gendre = 'male';
    break;
}

switch ($country) {
  case 'Netherlands':
  if ($gendre == 'male')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! <br>pretty common in weedland the ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> he probably goes to the wallen a lot has got to come from the ' . $country . '!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame him? <br>Everyone in ' . $country . ' is like that because of their bad humor!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be because he was smoking weed in ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste...<br>Probably because he is from ' . $country . ' everyone there is super lazy!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
  else if ($gendre == 'female')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! <br>pretty common in weedland the ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> she has got to come from the Wallen in the' . $country . '!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame her? <br>Everyone in ' . $country . ' is like that because of their bad humor!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be because she was smoking weed in ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste...<br>Probably because she is from ' . $country . ' everyone there is super lazy!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
    break;
  case 'Germany':
  if ($gendre == 'male')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! <br>das ist ziemlich üblich in ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> he has got to come from  ' . $country . 'since prostitution is completely legal over there!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very dirty mind on gas, but can you blame him? <br>Everyone in ' . $country . ' is like that!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! just how did he survive the gas <br>could that be because he was born in ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste...<br>Probably because he is from nazi ' . $country . '!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
  else if ($gendre == 'female')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! <br>das ist ziemlich üblich in ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> she has got to come from  ' . $country . 'since prostitution is completely legal over there!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very dirty mind on gas, but can you blame her? <br>Everyone in ' . $country . ' is like that!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! just how did she survive the gas <br>could that be because she was born in ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste...<br>Probably because she is from nazi ' . $country . '!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
    break;
  case 'Japan':
  if ($gendre == 'male')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! as well as a social disorder <br>pretty common in ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> he has got to come from ' . $country . '! that country with a lot of pedophiles';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame him? <br>Everyone any one would if they watched that many anime! <br>Everyone in ' . $country . ' is like that!';
          break;
      case 9000:
          break;
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be because of the tea he was always drinking in ' . $country . '?';
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste...<br>Probably because he is from ' . $country . ' <br>but that can sometimes also create the most unique ideas!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
  else if ($gendre == 'female')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! as well as a social disorder <br>pretty common in ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> she has got to come from ' . $country . ' that country with a lot of pedophiles!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame her? <br>Everyone any one would if they watched that many anime! <br>Everyone in ' . $country . ' is like that!';
          break;
      case 9000:
          break;
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be because of the tea she was always drinking in ' . $country . '?';
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste...<br>Probably because she is from ' . $country . ' <br>but that can sometimes also create the most unique ideas!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
    break;
  case 'USA':
  if ($gendre == 'male')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! <br>pretty common in school that crazy country, the ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> he has got to come from ' . $country . ' almost litteraly every one is talking about rape over there!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame him? <br>Everyone in ' . $country . ' has some weird fetish!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be because he was born in a state where guns were actually banned? <br>That is almost unheard of in the ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste because... AMERICA <br>Probably because he is from ' . $country . '!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
  else if ($gendre == 'female')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! <br>pretty common in school that crazy country, the ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> she has got to come from ' . $country .  'almost litteraly every one is talking about rape over there!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame her? <br>Everyone in ' . $country . ' has some weird fetish!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be because she was born in a state where guns were actually banned? <br>That is almost unheard of in the ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste because... AMERICA <br>Probably because she is from ' . $country . '!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }

    break;
  case 'North-Korea':
  if ($gendre == 'male')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! Probably a side effect of the radiation <br>pretty common in ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> he has gotten killed after 1 offence because he came from ' . $country . '!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame him? <br>Everyone in ' . $country . ' is messed up like that they got no internet like that!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be possible is there no rule for age? <br>get the joke? because he was born in ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste... but a PC is not easy to get by <br>Probably because he is from ' . $country . '!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
  else if ($gendre == 'female')
  {
    switch ($age)
    {
      case 666:
          echo $firstName . ' ' . $lastName . ' has Heksakosioiheksekontaheksafobia! Probably a side effect of the radiation <br>pretty common in ' . $country . '.';
          break;
      case 69:
          echo $firstName . ' ' . $lastName . ' is a sex addict!<br> she has gotten killed after 1 offence because she came from ' . $country . '!';
          break;
      case 34:
          echo $firstName . ' ' . $lastName . ' had a very diry mind, but can you blame her? <br>Everyone in ' . $country . ' is messed up like that they got no internet like that!';
          break;
      case 9000:
          echo $firstName . ' ' . $lastName . ' is over 9000!¡ years old! <br>could that be possible is there no rule for age? <br>get the joke? because she was born in ' . $country . '?';
          break;
      case 46584964:
          echo $firstName . ' ' . $lastName . ' probably likes to copy and paste... but a PC is not easy to get by <br>Probably because she is from ' . $country . '!';
          break;
      default:
      echo 'you messed up';
        break;
    }
  }
}


?>
