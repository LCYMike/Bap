<?php
$fullName = $_POST['fullName'];
$age = $_POST['age'];
$city = $_POST['city'];
echo $fullName . '<br>' . $age . '<br>' . $city . '<br>';
?>
