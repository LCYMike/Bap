<?php

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];

$age = $_POST['age'];

$country = $_POST['country'];
$city = $_POST['city'];
$adress = $_POST['adress'];
$postZip = $_POST['postZip'];

if ($age >= 18)
{
echo 'Hello Mr.' . $lastName . '.<br><br>';

echo 'The package has been paid for and will be send to.<br><br>';
echo $country . '<br>';
echo $city . '<br>' . $adress . ' ' . $postZip . '<br>';
echo $firstName . ' ' . $lastName;
}
else if ($age <=17)
{
  echo "Sorry but you're not old enough buy this product.";
}

?>
